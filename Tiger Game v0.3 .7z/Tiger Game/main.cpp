#include"groupProject.h"


int main()
{
    int dist[V];
    int pre[V];
    int av[V];
    int path[V];
    int hazard[V];
    Token_t T0,H1,H2,H3,H4,H5,H6,H7,H8,H9,H10,H11,H12,H13,H14,H15,H16,H17,H18;
    vector<Token_t> pieces,retn;
    vector<gameStats> g,sps;
        T0.color = RED;
    (T0.location).setPoint(2,4);
    pieces.push_back(T0);
    H1.color = BLUE;
    (H1.location).setPoint(12,0);
    pieces.push_back(H1);
    H2.color = BLUE;
    (H2.location).setPoint(12,1);
        pieces.push_back(H2);
    H3.color = BLUE;
    (H3.location).setPoint(12,2);
        pieces.push_back(H3);
    H4.color = BLUE;
    (H4.location).setPoint(12,3);
        pieces.push_back(H4);
    H5.color = BLUE;
    (H5.location).setPoint(12,4);
        pieces.push_back(H5);
    H6.color = BLUE;
    (H6.location).setPoint(12,5);
        pieces.push_back(H6);
    H7.color = BLUE;
    (H7.location).setPoint(12,6);
        pieces.push_back(H7);
    H8.color = BLUE;
    (H8.location).setPoint(12,7);
        pieces.push_back(H8);
    H9.color = BLUE;
    (H9.location).setPoint(12,8);
        pieces.push_back(H9);
    H10.color = BLUE;
    (H10.location).setPoint(11,0);
        pieces.push_back(H10);
    H11.color = BLUE;
    (H11.location).setPoint(11,1);
        pieces.push_back(H11);
    H12.color = BLUE;
    (H12.location).setPoint(11,2);
        pieces.push_back(H12);
    H13.color = BLUE;
    (H13.location).setPoint(11,3);
        pieces.push_back(H13);
    H14.color = BLUE;
    (H14.location).setPoint(11,4);
        pieces.push_back(H14);
    H15.color = BLUE;
    (H15.location).setPoint(11,5);
        pieces.push_back(H15);
    H16.color = BLUE;
    (H16.location).setPoint(11,6);
        pieces.push_back(H16);
    H17.color = BLUE;
    (H17.location).setPoint(11,7);
        pieces.push_back(H17);
    H18.color = BLUE;
    (H18.location).setPoint(11,8);
        pieces.push_back(H18);

    //tigerEatMan(pieces,31);
    //cout<<moveTowardsTiger(pieces,pieces[5])<<endl;
    //cout<<routeLength(30,94)<<endl;
    //Point_t x;
    //Point_t y;
    //x.setPoint(0,5);
    //cout<<getIndex(x)<<endl;
    //y.setPoint(10,4);
    //calHazard(pieces);
    //avaliable(60,1,dist,pre,av);
    //printArray(av,V);
    //Point_t y;
    //(pieces[0].location).setPoint(4,4);
    //cout<<moveTowardsTiger(pieces,pieces[10]);
    //cout<<nearestHumanFromPoint(pieces,x)<<endl;
    //cout<<nearestDis(pieces,x);
    //cout<<safeCheckAtPoint(pieces,x);
    //cout<<getIndex(x);
    //cout<<PointHumanMaxPath(pieces, T0.location)<<endl;;
    //cout<<sumRouteHuman(pieces,T0.location)<<endl;
    //cout<<pointEmpty(pieces,x);
    //avaliable(76,1);
    //printArray(av,V);
    //cout<<routeLength(59,59,dist,pre);
    //cout<<"tiger at:"<<getIndex(pieces[0].location);
    //cout<<pointEmpty(pieces,getPoint(38),dist,pre);
     //cout<<H_safeCheckAtPoint(pieces,getPoint(40),getPoint(39),dist,pre)<<endl;
    //randomMove(pieces,g,BLUE,dist,pre,av);
    //printGame(pieces,g);
    //cout<<getIndex(pieces[2].location)<<endl;
    //cout<<getTokenNum(pieces,41)<<endl;
    //graphPieces(pieces,dist,pre);
    Move_t ou;
    Color_t turn = RED;
    //!Here comes our move function!
    for(int i=0;i<100;i++)
    {
        graphPieces(pieces,dist,pre);
        if(i%2==0) turn=RED;
        else turn = BLUE;
        ou = MoveWithRtn(pieces,turn,retn);
        ou = Move(pieces,turn);
        printMove(pieces,ou);
        //movePieces(pieces,ou);
        //printPieces(pieces);
        pieces = retn;
    }

    //turn = RED;
    //ou = Move(pieces,turn);
    //cout<< "Token:"<<getTokenNum(pieces,getIndex(ou.token.location))<<endl;
    //cout<< "Destination:"<<getIndex(ou.destination)<<endl;
    //printGame(pieces,g);
    //printAllPossibleMoves();

    //printAllPossibleMoves();

    //routePath(17,40);
    //printArray(path,V);
    //cout<< routeLength(14,24);
    //routePath(4,56);
    //printArray(path);
    //cout<<getIndex(Point_t(1,2));
    return 0;
}
